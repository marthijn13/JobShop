# JobShop
Git repository for least slack algorithm

 - Class diagram (oplevering 1)
 - Activity diagram (oplevering 1)
 - Essay (oplevering 2)
 - Code (functioneel oplevering 1, volledig oplevering 2)


# Pseudocode
1. Lees het bestand uit en maak de jobs en machines aan
2. Bereken earliest finish van elke job
3. Bereken Least Slack van elke job
4. Start de eerste taak van de job met de minste slack
5. Controleer of er nog andere job gestart kan worden
6. herhaal stap 2-5 net zo lang tot alle jobs klaar zijn
